function sendtrigger_lpt(triggerport,triggervalue,triggertime)
if nargin < 3
    triggertime = 0.001;
end
lptwrite(triggerport, uint8(triggervalue));
WaitSecs(triggertime);
lptwrite(triggerport, uint8(0));