function names = dir2txt(path, type, o_path, o_name)
%dir_to_txt(path, type, o_path, o_name)

if nargin < 2
    o_path = '';
    o_name = '';
    type = 'mat';
end

%getting filenames in directory
listing = dir(path);
nfiles = length(listing);

if strcmp(type, 'mat')
    if length(listing)>2
        names(:,2) = extractfield(listing(3:end), 'name')';
        names(:,1) = {path};
    else
        names = cell(1,2);
    end
    
    if nargout < 1
        save(strcat(o_path, o_name), 'names')
    end
end

if strcmp(type, 'time')
    if length(listing)>2
        names(:,3) = num2cell(extractfield(listing(3:end), 'datenum')');
        names(:,2) = extractfield(listing(3:end), 'name')';
        names(:,1) = {path};
    else
        names = cell(1,3);
    end
    
    if nargout < 1
        save(strcat(o_path, o_name), 'names')
    end
end


if strcmp(type, 'txt')
    fid = fopen(strcat(o_path,o_name),'w');
    %creates a text file containing the names of the last.fm tag files
    for k=3:nfiles
        fprintf(fid,'%s\r\n',strcat(path, listing(k,1).name));
        %  fprintf(listing(k,1).name);
    end
end
fclose('all');