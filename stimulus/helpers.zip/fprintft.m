function fprintft(format, varargin)
fprintf('%s:\t',datestr(now,'dd-mm-yyyy HH:MM:SS:FFF'))
fprintf(format,varargin{:})