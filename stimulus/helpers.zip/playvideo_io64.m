function playvideo_io64(windowPtr, moviePath, volume, rate, verbose, ioObject, triggerport, trigger_start, trigger_end)
if nargin < 6
    triggers = false;
else
    triggers = true;
end
Screen('Preference', 'VisualDebuglevel', 3);

HideCursor;
KbReleaseWait;

%make sure all triggers are "turned off"
if triggers
    sendtrigger_io64(ioObject,triggerport,0); 
end

%open the movie
[moviePtr, movieduration, fps, width, height, frames] = Screen('OpenMovie',windowPtr, moviePath);
Screen('Flip',windowPtr);

% Clear screen to black background color
Screen('FillRect', windowPtr, 0);
Screen('Flip', windowPtr);
Screen('PlayMovie',moviePtr,rate,0,volume);

% get start time
tstart = GetSecs;

% send start trigger
if triggers
    sendtrigger_io64(ioObject,triggerport,trigger_start);
end

% Start playback
for iFrame = 1:(frames-1)
    [tex, ~] = Screen('GetMovieImage', windowPtr, moviePtr, 1);
    fprintft('Drawing frame %d - %d\n',iFrame,tex)
    if tex >0
        Screen('DrawTexture',windowPtr,tex);
        Screen('Flip',windowPtr);
        Screen('Close',tex);
    end
end
% get end time
tend = GetSecs;

% send end trigger
if triggers
    sendtrigger_io64(ioObject,triggerport,trigger_end);
end

% Stop playback:
Screen('Flip',windowPtr);
% droppedframes = Screen('PlayMovie', moviePtr, 0);
Screen('PlayMovie', moviePtr, 0);
Screen('CloseMovie', moviePtr);
duration=  tend-tstart;

if ~verbose
    fprintft('Movie duraction %1.2f seconds\n',movieduration)
    fprintft('Playback duration %1.2f seconds\n',duration)
    fprintft('Playback difference %1.2f seconds\n',movieduration-duration)
    fprintft('Framerate %1.2f fps\n',fps)
%     fprintft('Dropped frames %d\n',droppedframes)
    fprintft('Frames in movie %d\n',frames)
    fprintft('Estimated frames %d frames\n',round(movieduration*fps))
    fprintft('Video resolution %dx%d pixels\n',width,height)
end