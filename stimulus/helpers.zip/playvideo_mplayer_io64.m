function playvideo_mplayer_io64(moviePath, ioObject, triggerport, trigger_start, trigger_end)

if nargin < 3
    triggers = false;
    % moviePath = 'C:\Users\neurolab\Desktop\experiments\pawel\updated_working\education_engagement_eyetracking\data\stimuli\05a.Why_Do_We_Have_More_Boys_Than_Girls-Trim_padded.avi';
    moviePath = 'C:\Video\The_Present_720x480.avi';
    addpath(genpath('./'))
else
    triggers = true;
end
% Screen('Preference', 'VisualDebuglevel', 3);
mplayerPath = GetFullPath('./helpers/mplayer/');
% mplayerPath = 'C:\Users\PC3TUSER\Documents\MATLAB\scripts\helpers\mplayer';
 
% [~,output] = system([mplayerPath 'mplayer.exe -ao help']);
% [~,output] = system([mplayerPath 'mplayer.exe -vo help']);
 
audiocodec = 'dsound'; % dsound
videocodec = 'gl'; %gl  directx
 
settings = [' -ao ' audiocodec ' -vo ' videocodec ' -fs -quiet '];
 
HideCursor;
KbReleaseWait;
 
% create command to play using mplayer
command = [mplayerPath 'mplayer.exe' settings moviePath];
 
%make sure all triggers are "turned off"
if triggers
    sendtrigger_io64(ioObject,triggerport,0); 
end
 
% send start trigger
if triggers
    sendtrigger_io64(ioObject,triggerport,trigger_start,0.002);
end
 
% system(command)
system(['cmd /c ' command]);
% send end trigger
if triggers
    sendtrigger_io64(ioObject,triggerport,trigger_end,0.002);
end
 
% Stop playback:
% Screen('Flip',windowPtr);