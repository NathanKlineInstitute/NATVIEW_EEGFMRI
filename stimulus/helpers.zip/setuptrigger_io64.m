function ioObject = setuptrigger_io64
ioObject = io64;
status = io64(ioObject);
if status
    error('IO not working')
end