function output = encode_video_ffmpeg(directory_in,filename_in,directory_out,filename_out)
if nargin < 1
directory_in = 'C:\Users\jenma\Desktop\Dropbox\Experiments\stimuliTrackerTest\stimuli\';
filename_in = 'video_1280_1024_noiseburst_repeat=1.avi';
directory_out = 'C:\Users\jenma\Desktop\Dropbox\Experiments\stimuliTrackerTest\stimuli\';
filename_out = 'video_1280_1024_noiseburst_repeat=1.avi';
end

ffmpegpath = GetFullPath('./helpers/ffmpeg/bin/');
if exist(ffmpegpath,'dir')
addpath(genpath(ffmpegpath))

settings = ' -c:v mpeg4 -vtag xvid -b:v 4000k -q:a 1 -y ';

command = [ffmpegpath 'ffmpeg.exe -i ' directory_in filename_in settings directory_out filename_out];

[~,output] = system(command);
else
	error('Could not find %s',ffmpegpath)
end