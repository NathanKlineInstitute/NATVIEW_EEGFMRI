function sendtrigger_io64(ioObject,triggerport,triggervalue,triggertime)
if nargin < 4
    triggertime = 0.001;
end
if nargin < 1
    triggervalue = 1;
    triggerport = hex2dec('D010');
    ioObject = setuptriggers
end

io64(ioObject, triggerport, uint16(triggervalue));
WaitSecs(triggertime);
io64(ioObject, triggerport, uint16(0));